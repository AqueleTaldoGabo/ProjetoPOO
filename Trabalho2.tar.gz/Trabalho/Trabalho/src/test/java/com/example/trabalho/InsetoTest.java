package com.example.trabalho;

import javafx.collections.ObservableList;
import org.junit.jupiter.api.Test;

import java.sql.*;

import static org.junit.jupiter.api.Assertions.*;

class InsetoTest {
    @Test
    void testeRetornaAleatorio() {
        Inseto inseto = new Inseto();
        for (int i = 0; i < 10; i++) {
            int resultado = inseto.retornaAleatorio();
            assertTrue(resultado > 0 || resultado == -1, "Não existem insetos no banco OU o os Id´s são invalidos em" + i + ": " + resultado);
        }
    }
    @Test
    void testeLista() {
         Inseto inseto = new Inseto();
         ObservableList<String> resultado = inseto.lista();
         assertInstanceOf(javafx.collections.ObservableList.class, resultado, "Deve ser retornado um ObservableList");
    }

    @Test
    void deletarInsetoInexistente() {
        Inseto inseto = new Inseto();
        String nomeErro = "Erro" + System.currentTimeMillis();
        assertDoesNotThrow(() -> inseto.deletarInseto(nomeErro), "O metodo deletarInseto() não deve lançar uma exceção quando tentar deletar um inseto inexistente no banco");
    }

    @Test
    void verificaInsercao(){
        new Inseto().criaInseto("Joaor", "Pterodal");
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Planta", "postgres", "12345");
             PreparedStatement stmt = connection.prepareStatement("SELECT nome FROM inseto WHERE nome = ?")) {

            stmt.setString(1, "Joaor");
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next(), "Planta de teste deve existir antes de ser deletada");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    void verificaDelecao(){
        new Inseto().criaInseto("Joaor", "Pterodal");
        new Inseto().deletarInseto("Joaor");
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Planta", "postgres", "12345");
             PreparedStatement stmt = connection.prepareStatement("SELECT nome FROM planta WHERE nome = ?")) {

            stmt.setString(1, "PlantaADeletar");
            try (ResultSet rs = stmt.executeQuery()) {
                assertFalse(rs.next(), "Planta de teste não deve existir apos ser deletada");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testCriaInsetoeVerificaLista() {
        Inseto inseto = new Inseto();
        inseto.criaInseto("NovoInseto", "tipo1");
        ObservableList<String> list = inseto.lista();
        System.out.println(list);
        assertTrue(list.stream().anyMatch(s -> s.trim().equals("NovoInseto")));
    }
}