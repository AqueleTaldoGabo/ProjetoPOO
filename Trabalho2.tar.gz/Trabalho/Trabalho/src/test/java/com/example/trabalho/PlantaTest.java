package com.example.trabalho;

import javafx.collections.ObservableList;
import org.junit.jupiter.api.Test;
import java.sql.*;
import static org.junit.jupiter.api.Assertions.*;

public class PlantaTest {

    @Test
    public void testeDeletarPlanta() throws SQLException {
        Planta planta = new Planta();

        planta.criaPlanta("PlantaADeletar", "Tipo1", 5);

        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Planta", "postgres", "12345");
             PreparedStatement stmt = connection.prepareStatement("SELECT nome FROM planta WHERE nome = ?")) {

            stmt.setString(1, "PlantaADeletar");
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next(), "Planta de teste deve existir antes de ser deletada");
            }
        }

        planta.deletarPlanta("PlantaADeletar");

        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Planta", "postgres", "12345");
             PreparedStatement stmt = connection.prepareStatement("SELECT nome FROM planta WHERE nome = ?")) {

            stmt.setString(1, "PlantaADeletar");
            try (ResultSet rs = stmt.executeQuery()) {
                assertFalse(rs.next(), "Planta de teste não deve existir apos ser deletada");
            }
        }
    }

    @Test
    public void testeCriarPlanta() throws SQLException {
        Planta planta = new Planta();

        planta.criaPlanta("NovaPlanta", "Tipo1", 5);

        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Planta", "postgres", "12345");
             PreparedStatement stmt = connection.prepareStatement("SELECT nome, tipo, custo FROM planta WHERE nome = ?")) {

            stmt.setString(1, "NovaPlanta");
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next(), "Nova planta deve ser adicionada ao banco");
                assertEquals("NovaPlanta", rs.getString("nome"));
                assertEquals("Type1", rs.getString("tipo"));
                assertEquals(5, rs.getInt("custo"));
            }
        }

        planta.deletarPlanta("NovaPlanta");
    }

    @Test
    public void testeMudarPlanta() throws SQLException {
        Planta planta = new Planta();

        planta.criaPlanta("PlantaTeste", "Tipo1", 5);

        planta.mudarPlanta("PlantaTeste", "PlantaAtualizada", 10, "Tipo2");

        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Planta", "postgres", "12345");
             PreparedStatement stmt = connection.prepareStatement("SELECT nome, custo, tipo FROM planta WHERE nome = ?")) {

            stmt.setString(1, "PlantaAtualizada");
            try (ResultSet rs = stmt.executeQuery()) {
                assertTrue(rs.next(), "planta atualizada deve estar no banco");
                assertEquals("PlantaAtualizada", rs.getString("nome"));
                assertEquals(10, rs.getInt("custo"));
                assertEquals("Tipo2", rs.getString("tipo"));
            }
        }

        planta.deletarPlanta("PlantaAtualizada");
    }
    @Test
    void testeAtualizacaodaLista(){
        ObservableList list = new Planta().lista();
        new Planta().criaPlanta("AAAA", "ADSA", 33);
        ObservableList list2 = new Planta().lista();

        assertNotEquals(list, list2);
    }
}
