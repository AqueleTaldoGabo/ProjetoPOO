package com.example.trabalho;
import java.sql.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

class PoteTest {

    @BeforeEach
    void setUp(){
        String url = "jdbc:postgresql://localhost:5432/Planta";
        String usuario = "postgres";
        String senha = "12345";

    }

    @Test
    void TestaSeColocaPoteFunciona() {
        Pote dao = new Pote();
        int poteId = 4;
        int plantaId = 2;
        dao.colocaPote(poteId,plantaId);

        try (Connection connection = DriverManager.getConnection(dao.url, dao.usuario, dao.senha);
             PreparedStatement stmt = connection.prepareStatement(
                     "SELECT quantiaagua, doenca, plantaid FROM Pote WHERE poteid = ?")) {

            stmt.setInt(1, poteId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int quantia = rs.getInt("quantiaagua");
                boolean doenca = rs.getBoolean("doenca");
                int planta = rs.getInt("plantaid");

                assert quantia == 0 : "Esperava quantia de agua = 0, mas veio " + quantia;
                assert !doenca : "Esperava doenca = false, mas veio true";
                assert planta == plantaId : "Esperava plantaid = " + plantaId + ", mas veio " + planta;

            } else {
                assert false : "Nenhum registro encontrado para poteid = " + poteId;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Test
    void TestaSeRegarFunciona() {
        Pote dao = new Pote();
        int poteId = 4;

        dao.Regar(poteId);

        try (Connection connection = DriverManager.getConnection(dao.url, dao.usuario, dao.senha);
             PreparedStatement stmt = connection.prepareStatement("SELECT quantiaagua FROM Pote WHERE poteid = ?")) {

            stmt.setInt(1, poteId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int quantia = rs.getInt("quantiaagua");

                assert quantia == 100 : "Esperava quantia de agua = 100, mas veio " + quantia;

            } else {
                assert false : "Nenhum registro encontrado para poteid = " + poteId;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Test
    void TestaSeInfecta() {
        Pote dao = new Pote();
        int poteId = 4;
        int insetoId = 2;
        dao.Infecta(poteId, insetoId);

        try (Connection connection = DriverManager.getConnection(dao.url, dao.usuario, dao.senha);
             PreparedStatement stmt = connection.prepareStatement("SELECT insetoid, doenca FROM Pote WHERE poteid = ?")) {

            stmt.setInt(1, poteId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int inseto = rs.getInt("insetoid");
                boolean doenca = rs.getBoolean("doenca");

                assert inseto == insetoId : "Esperava insetoid = " + insetoId + ", mas veio " + inseto;
                assert doenca : "Esperava doenca = true";
            } else {
                assert false : "Nenhum registro encontrado para poteid = " + poteId;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Test
    void testaSelimpaPlanta() {
        Pote dao = new Pote();
        int poteId = 4;

        dao.limpaPlanta(poteId);

        try(Connection connection = DriverManager.getConnection(dao.url, dao.usuario, dao.senha);
            PreparedStatement stmt = connection.prepareStatement("SELECT insetoid, doenca FROM Pote WHERE poteid = ?")) {

            stmt.setInt(1, poteId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Object inseto = rs.getObject("insetoid");
                boolean doenca = rs.getBoolean("doenca");

                assert inseto == null : "Esperava insetoid = null";
                assert !doenca : "Esperava doenca = false";
            } else {
                assert false : "Nenhum registro encontrado para poteid = " + poteId;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @Test
    void testaGastarAgua(){
        Pote dao = new Pote();
        int poteId = 4;
        int quantia = 0;
        
        try(Connection connection = DriverManager.getConnection(dao.url, dao.usuario, dao.senha);
            PreparedStatement stmt = connection.prepareStatement("SELECT quantiaagua FROM Pote WHERE poteid = ?")) {

            stmt.setInt(1, poteId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                quantia = rs.getInt("quantiaagua");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        dao.gastarAgua(4);

        try(Connection connection = DriverManager.getConnection(dao.url, dao.usuario, dao.senha);
            PreparedStatement stmt = connection.prepareStatement("SELECT quantiaagua FROM Pote WHERE poteid = ?")) {

            stmt.setInt(1, poteId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                assertNotEquals(rs.getInt("quantiaagua"), quantia);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}