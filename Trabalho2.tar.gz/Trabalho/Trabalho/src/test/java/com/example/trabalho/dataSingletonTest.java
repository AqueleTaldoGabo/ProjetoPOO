package com.example.trabalho;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class dataSingletonTest {
    @Test
    void Modificacao(){
        dataSingleton sng1 = dataSingleton.getInstance();
        dataSingleton sng2 = dataSingleton.getInstance();

        sng1.setPote(40);
        sng1.setNome("Nome1");

        assertEquals(40, sng2.getPote(), "Sng2 deve saber das modificacoes feitas em sng1");
        assertEquals("Nome1", sng2.getNome(), "Sng2 deve saber das modificacoes feitas em sng1");

        sng2.setTipo("Tipo2");
        assertEquals("Tipo2", sng1.getTipo(), "Sng1 deve saber das modificacoes feitas em sng2");

    }

}