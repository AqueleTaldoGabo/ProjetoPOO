package com.example.trabalho;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Inseto {
    String url = "jdbc:postgresql://localhost:5432/Planta";
    String usuario = "postgres";
    String senha = "12345";

    public void criaInseto(String nome, String tipo){
        String sql = "INSERT INTO inseto (nome, tipoplanta, dano) VALUES (?, ?, ?) RETURNING insetoid";

        try (Connection connection = DriverManager.getConnection(url, usuario, senha);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");

            statement.setString(1, nome);
            statement.setString(2, tipo);
            statement.setInt(3, 1);


            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    int idGerado = rs.getInt("insetoid");
                    System.out.println("Inseto inserida com ID: " + idGerado);
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }
    public void deletarInseto(String insetoNome){
        String sql = "DELETE FROM inseto WHERE nome = ?";

        try (Connection connection = DriverManager.getConnection(url, usuario, senha);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");

            String nomeExcluir = insetoNome;
            statement.setString(1, nomeExcluir);

            int linhasExcluidas = statement.executeUpdate();

            if (linhasExcluidas > 0) {
                System.out.println("Planta com ID " + nomeExcluir + " exclu�do com sucesso!");
            } else {
                System.out.println("Nenhuma planta encontrado com ID " + nomeExcluir);
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }
    public void mudarInseto(String nome, String nomeNovo, String tipo){
        String sql = "UPDATE inseto set nome = ?, tipoplanta = ? WHERE nome = ?";

        try (Connection connection = DriverManager.getConnection(url, usuario, senha);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");
            statement.setString(3, nome);

            if(!nomeNovo.isEmpty())
                statement.setString(1, (nomeNovo));
            else
                statement.setString(1, nome);
            if(!tipo.isEmpty()) {
                statement.setString(2, tipo);
            }
            int rowsAffected = statement.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!2");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }

    public ObservableList<String> lista(){
        String sql = "Select nome From inseto";

        List<String> lista = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(url, usuario, senha);
             PreparedStatement statement = connection.prepareStatement(sql)) {


            try (ResultSet result = statement.executeQuery()) {

                while (result.next()) {
                    String nome = result.getString("nome");
                    System.out.println(nome);
                    lista.add(nome);
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
        ObservableList<String> list = FXCollections.observableArrayList(lista);

        return list;
    }
    public int retornaAleatorio(){
        String sql = "Select insetoid from inseto order by RANDOM() limit 1";
        int insetoId = -1;
        try (Connection connection = DriverManager.getConnection(url, usuario, senha);
             PreparedStatement statement = connection.prepareStatement(sql)) {

            try (ResultSet result = statement.executeQuery()) {

                if (result.next()) {
                    insetoId = result.getInt("insetoid");
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
        return insetoId;
    }
}
