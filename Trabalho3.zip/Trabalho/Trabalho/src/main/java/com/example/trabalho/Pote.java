package com.example.trabalho;

import java.sql.*;

public class Pote {
    private int QUANTIA_PADRAO = 100;
    DadosEntradaBanco deb = DadosEntradaBanco.getInstance();

    public void colocaPote(int poteid, int plantaid){
        String sql = "UPDATE Pote SET quantiaagua = ?, doenca = ?, plantaid = ? where poteid = ?";

        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");

            statement.setInt(4, poteid);
            statement.setInt(1, 0);
            statement.setBoolean(2, false);
            statement.setInt(3, plantaid);
            int rowsAffected = statement.executeUpdate();

        } catch (SQLException e) {

            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }

    /*Melhora da nomeclatura, usando um padrão e melhora de feedback*/
    public void Regar(int poteId) {
        String sql = "UPDATE Pote Set quantiaagua = ? WHERE poteid = ?";
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, QUANTIA_PADRAO);
            statement.setInt(2, poteId);
            int linhasAfetadas = statement.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("✅ Pote ID " + poteId + " regado com sucesso! Linhas afetadas: " + linhasAfetadas);
            } else {
                System.out.println("Nenhum pote encontrado com o ID " + poteId + " para regar.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao regar o pote no banco de dados.");
                    System.err.println("Detalhes do erro: " + e.getMessage());
        }
    }
    public void RetiraPote(int numpote){
        String sql = "UPDATE Pote Set plantaid = ?, insetoid = ?, doenca = ? WHERE poteid = ?";
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");

            statement.setObject(1, null);
            statement.setObject(2, null);
            statement.setBoolean(3, false);
            statement.setInt(4, numpote);
            int rowsAffected = statement.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }

    public void gastarAgua(int numpote){
        int quantia =0, custo=0;
        boolean doenca=false;
        String sql = "SELECT quantiaagua, custo, doenca FROM pote join planta on pote.plantaid = planta.plantaid where poteid = ?";
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setObject(1, numpote);
            try (ResultSet result = statement.executeQuery()) {

                if (result.next()) {
                    quantia = result.getInt("quantiaagua");
                    custo = result.getInt("custo");
                    doenca = result.getBoolean("doenca");
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados1!");
            System.out.println("Detalhes: " + e.getMessage());
        }


        sql = "UPDATE Pote set quantiaagua = ? WHERE poteid = ?";
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");

            statement.setObject(1, (quantia-custo));
            if(doenca){
                statement.setObject(1, (quantia-custo*1.5));
                if((quantia-custo*1.5)<0){
                    statement.setObject(1, 0);
                }
            }
            if((quantia-custo) < 0){
                statement.setObject(1, 0);
            }

            statement.setInt(2, numpote);
            int rowsAffected = statement.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!2");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }
    /*Parâmetros renomeados para melhorar a leitura
    * lógica de infecção separada para melhorar o fluxo de lógica do
    código
    * feedback aprimorado ao realizar operações
    * Tratamento de exceção adicional*/
    public void Infecta(int poteId, int insetoId){
        final String sql = "UPDATE Pote SET insetoid = ?, doenca = ? WHERE poteid = ?";
        Object insetoParametro;
        boolean statusDoenca;
        if (insetoId == -1) {
            insetoParametro = null;
            statusDoenca = false;
        } else {
            insetoParametro = insetoId;
            statusDoenca = true;
        }
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setObject(1, insetoParametro);
            statement.setBoolean(2, statusDoenca);
            statement.setInt(3, poteId);
            int linhasAfetadas = statement.executeUpdate();
            if (linhasAfetadas > 0) {
                String acao = (insetoId == -1) ? "desinfectado" : "infectado (Inseto ID: " + insetoId + ")";
                System.out.println(" Pote ID " + poteId + " " + acao + " com sucesso.");
            } else {
                System.out.println("Nenhum pote encontrado com o ID " + poteId + " para atualização.");
            }
        } catch (SQLException e) {
            System.err.println(" Erro ao atualizar o status de infecção do pote.");
            System.err.println("Detalhes da exceção: " +
                    e.getMessage());
        }
    }
    public void limpaPlanta(int num){
        String sql = "UPDATE Pote Set insetoid = ?, doenca = ? WHERE poteid = ?";
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");

            statement.setObject(1, null);
            statement.setObject(2, false);

            statement.setInt(3, num);
            int rowsAffected = statement.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }
}
