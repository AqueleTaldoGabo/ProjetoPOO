package com.example.trabalho;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class listaController {
    DadosEntradaBanco deb = DadosEntradaBanco.getInstance();
    dataSingleton data = dataSingleton.getInstance();

    @FXML
    private Button btnCancelar;

    @FXML
    private Button btnConfirmar;

    @FXML
    private ComboBox<String> lisLista;

    @FXML
    public void initialize(){

        String sql = "Select nome From planta";

        List<String> lista = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {


            try (ResultSet result = statement.executeQuery()) {

                while (result.next()) {
                    String nome = result.getString("nome");
                    lista.add(nome);
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
        ObservableList<String> list = FXCollections.observableArrayList(lista);


        lisLista.setItems(list);
    }

    @FXML
    public void Confimar(ActionEvent actionEvent) throws IOException {
        String sql = "Select plantaid From planta where nome = ?";
        int id=0;
        List<String> lista = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, lisLista.getValue());
            try (ResultSet result = statement.executeQuery()) {
                System.out.println(lisLista.getValue());
                if (result.next()) {
                    id = result.getInt("plantaid");
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
        new Pote().colocaPote(data.getPote(), id);
        Stage stage = (Stage) btnConfirmar.getScene().getWindow();
        stage.close();
        /*
        Refatoração:
        Evitando exceções em todos fxmlloaders utilizando "Objects.requireNonNull()"
         */
        Parent planta = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("inserido.fxml")));
        Scene plan = new Scene(planta);
        Stage stage1= new Stage();
        stage1.setTitle("New Window");
        stage1.setScene(plan);
        stage1.show();
    }

    @FXML
    public void Cancelar(ActionEvent actionEvent) {
        Stage stage = (Stage) btnCancelar.getScene().getWindow();
        stage.close();
    }
}