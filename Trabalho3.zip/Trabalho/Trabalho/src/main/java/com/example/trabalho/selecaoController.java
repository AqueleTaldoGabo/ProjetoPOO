package com.example.trabalho;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class selecaoController {
    dataSingleton data = dataSingleton.getInstance();
    @FXML
    private Button btnAlterar;

    @FXML
    private Button btnDeletar;

    @FXML
    private Button btnInserir;

    @FXML
    private Button btnTroca;

    @FXML
    private Label lblNomeLista;

    @FXML
    private ListView<String> listviewPlanta;

    @FXML
    public void initialize(){
        listviewPlanta.setItems(new Planta().lista());
    }

    // Refatoração 1: Adicionada validação para verificar se um item está selecionado na ListView antes de executar ações como deletar ou alterar.
    // Isso evita erros em tempo de execução e melhora a experiência do usuário, sem envolver operações de banco de dados.
    private boolean itemSelecionado() {
        return listviewPlanta.getSelectionModel().getSelectedItem() != null;
    }

    // Refatoração 2: Extraída a lógica repetida de carregamento de FXML e criação de cena/janela em um método auxiliar.
    // Isso reduz a duplicação de código, melhora a legibilidade e facilita a manutenção.
    private void abrirJanela(String fxmlPath, String titulo) throws IOException {
        /*
        Refatoração:
        Evitando exceções em todos fxmlloaders utilizando "Objects.requireNonNull()"
         */
        Parent planta = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(fxmlPath)));
        Scene scene = new Scene(planta);
        Stage stage = new Stage();
        stage.setTitle(titulo);
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    public void inserir() throws IOException {
        abrirJanela("inserir.fxml", "New Window");
    }

    @FXML
    public void deletar() throws IOException {
        if (!itemSelecionado()) {
            System.out.println("Nenhum item selecionado para deletar.");
            return;
        }
        if(lblNomeLista.getText().equals("Plantas"))
            new Planta().deletarPlanta(listviewPlanta.getSelectionModel().getSelectedItem());
        else
            new Inseto().deletarInseto(listviewPlanta.getSelectionModel().getSelectedItem());
        abrirJanela("inserido.fxml", "New Window");
        listviewPlanta.setItems(new Planta().lista());
    }

    @FXML
    public void alterar() throws IOException {
        if (!itemSelecionado()) {
            System.out.println("Nenhum item selecionado para alterar.");
            return;
        }
        data.setNome(listviewPlanta.getSelectionModel().getSelectedItem());
        data.setTipo(lblNomeLista.getText());
        abrirJanela("alterar.fxml", "New Window");
    }

    @FXML
    public void trocar() {
        if (btnTroca.getText().equals("Insetos...")) {
            btnTroca.setText("Plantas...");
            lblNomeLista.setText("Insetos");
            listviewPlanta.setItems(new Inseto().lista());
        } else {
            btnTroca.setText("Insetos...");
            lblNomeLista.setText("Plantas");
            listviewPlanta.setItems(new Planta().lista());
        }
    }

    @FXML
    public void sair(ActionEvent actionEvent) throws IOException {
        /*
        Refatoração:
        Evitando exceções em todos fxmlloaders utilizando "Objects.requireNonNull()"
         */
        Parent fxmlLoader =  FXMLLoader.load(Objects.requireNonNull(getClass().getResource("menu.fxml")));
        Scene scene = new Scene(fxmlLoader);
        Stage window = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }
}
