package com.example.trabalho;

/*
Refatoração:
simplifica o acesso ao url, usuário e senha para o resto das classes.
*/
public class DadosEntradaBanco {
    private static final DadosEntradaBanco instance = new DadosEntradaBanco();

    String url = "jdbc:postgresql://localhost:5432/Planta";
    String usuario = "postgres";
    String senha = "12345";

    private DadosEntradaBanco(){}

    public static DadosEntradaBanco getInstance(){ return instance; }

    public String getUrl(){ return url; }

    public String getUsuario(){ return usuario; }

    public String getSenha(){ return senha; }
}
