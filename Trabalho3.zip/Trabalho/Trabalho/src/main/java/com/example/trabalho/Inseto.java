package com.example.trabalho;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Inseto {
    DadosEntradaBanco deb = DadosEntradaBanco.getInstance();

    public void criaInseto(String nome, String tipo){
        String sql = "INSERT INTO inseto (nome, tipoplanta, dano) VALUES (?, ?, ?) RETURNING insetoid";

        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");

            statement.setString(1, nome);
            statement.setString(2, tipo);
            statement.setInt(3, 1);


            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    int idGerado = rs.getInt("insetoid");
                    System.out.println("Inseto inserida com ID: " + idGerado);
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }
    public void deletarInseto(String insetoNome){
        String sql = "DELETE FROM inseto WHERE nome = ?";

        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            System.out.println("Conex�o realizada com sucesso!");

            /*
            Refatoração:
            transformando insetoNome em uma inline variable
             */
            statement.setString(1, insetoNome);

            int linhasExcluidas = statement.executeUpdate();

            if (linhasExcluidas > 0) {
                System.out.println("Planta com ID " + insetoNome + " exclu�do com sucesso!");
            } else {
                System.out.println("Nenhuma planta encontrado com ID " + insetoNome);
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }
    /*Alteração nos nomes dos parâmetros para deixá-los mais claros
     * lógica de if/else simplificada usando o operador ternário
     * Melhorado o feedback para o uso do método*/
    public void mudarInseto(String nomeAtual, String novoNome, String novoTipoPlanta){
        final String sql = "UPDATE inseto SET nome = ?, tipoplanta = ? WHERE nome = ?";
        final String nomeAjustado = novoNome.isEmpty() ? nomeAtual : novoNome;
        final String tipoPlantaAjustado = novoTipoPlanta.isEmpty() ? null : novoTipoPlanta;
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, nomeAjustado);
            if (tipoPlantaAjustado == null) {
                statement.setNull(2, java.sql.Types.VARCHAR);
            } else {
                statement.setString(2, tipoPlantaAjustado);
            }
            statement.setString(3, nomeAtual);
            int linhasAfetadas = statement.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Inseto '" + nomeAtual + "' atualizado para Nome: '" + nomeAjustado + "'. Linhas afetadas: " + linhasAfetadas);
            } else {
                System.out.println("Nenhum inseto encontrado com o nome '" + nomeAtual + "' para ser atualizado.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar o inseto no banco de dados.");
                    System.err.println("Detalhes da exceção: " + e.getMessage());
        }
    }


    public ObservableList<String> lista(){
        String sql = "Select nome From inseto";

        List<String> lista = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {


            try (ResultSet result = statement.executeQuery()) {

                while (result.next()) {
                    String nome = result.getString("nome");
                    System.out.println(nome);
                    lista.add(nome);
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
        /*
        Refatoração?
        Remoção de redundancia do return.
         */
        return FXCollections.observableArrayList(lista);
    }
    public int retornaAleatorio(){
        String sql = "Select insetoid from inseto order by RANDOM() limit 1";
        int insetoId = -1;
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            try (ResultSet result = statement.executeQuery()) {

                if (result.next()) {
                    insetoId = result.getInt("insetoid");
                }
            }

        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
        return insetoId;
    }
}
