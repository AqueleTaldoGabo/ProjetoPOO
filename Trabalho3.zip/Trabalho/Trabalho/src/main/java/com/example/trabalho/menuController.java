package com.example.trabalho;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;


public class menuController {
    @FXML
    private Label titleLbl;
    @FXML
    private Button jogarBtn;
    @FXML
    private Button baralhoBtn;
    @FXML
    private Button sairBtn;

    //Esta refatoração tem como foco deixar mais evidente a
    //troca de telas que ocorre no JavaFx
    /*A variável window foi alterada para stageAtual, para simbolizar
    melhor o seu significado no código */
        /*root agora simboliza melhor o elemento da hierarquia Scene*/
    /*A variável source foi introduzida para melhorar o fluxo de
    leitura*/
    public void jogarButtonClick(ActionEvent actionEvent) throws IOException {
        /*
        Refatoração:
        Evitando exceções em todos fxmlloaders utilizando "Objects.requireNonNull()"
         */
        Parent fxmlLoader =  FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Principal.fxml")));
        Scene scene = new Scene(fxmlLoader);
        Stage window = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();

    }

    public void baralhoButtonClick(ActionEvent actionEvent) throws IOException {
        /*
        Refatoração:
        Evitando exceções em todos fxmlloaders utilizando "Objects.requireNonNull()"
         */
        Parent root =  FXMLLoader.load(Objects.requireNonNull(getClass().getResource("selecao.fxml")));
        Node source = (Node) actionEvent.getSource();
        Stage stageAtual = (Stage) source.getScene().getWindow();
        Scene scene = new Scene(root);
        stageAtual.setScene(scene);
        stageAtual.show();
    }

    public void sairButtonClick(ActionEvent actionEvent) {
        Stage stage = (Stage) sairBtn.getScene().getWindow();
        stage.close();
    }
}