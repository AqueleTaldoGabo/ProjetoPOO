package com.example.trabalho;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class infoController {
    DadosEntradaBanco deb = DadosEntradaBanco.getInstance();

    private double quantiaaagua;
    dataSingleton data = dataSingleton.getInstance();

    @FXML
    public Button btnLimpar;

    @FXML
    private Label lblConsumo;

    @FXML
    private Label lblInfestado;

    @FXML
    private Label lblNome;

    @FXML
    private Label lblTipo;

    @FXML
    private ProgressBar pgAguaPlanta;

    @FXML
    public void initialize(){
        System.out.println("aaaaa");

        atualiza();

    }

    public void LimparPlanta(ActionEvent actionEvent) throws IOException {
        if(quantiaaagua > 0) {
            new Pote().limpaPlanta(data.getPote());
            String sql = "UPDATE Pote set quantiaagua = ? WHERE poteid = ?";
            try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
                 PreparedStatement statement = connection.prepareStatement(sql)) {

                System.out.println("Conex�o realizada com sucesso!");

                statement.setObject(1, 0);


                statement.setInt(2, data.getPote());
                int rowsAffected = statement.executeUpdate();

            } catch (SQLException e) {
                System.out.println("Erro na opera��o com o banco de dados!2");
                System.out.println("Detalhes: " + e.getMessage());
            }
            novaTela("Retirado");
        }else{
            novaTela("Não tem agua");
        }
        atualiza();
    }
    public void atualiza(){
        String sql = "Select * From pote join planta on pote.plantaid = planta.plantaid where poteid = ?";
        try (Connection connection = DriverManager.getConnection(deb.getUrl(), deb.getUsuario(), deb.getSenha());
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, data.getPote());

            try (ResultSet result = statement.executeQuery()) {

                if (result.next()) {
                    quantiaaagua = result.getDouble("quantiaagua");
                    String nome = result.getString("nome");
                    String tipo = result.getString("tipo");
                    double custo = result.getDouble("custo");
                    atualizarUI(nome, tipo, custo, quantiaaagua);
                    lblInfestado.setText("Infestado: " + result.getBoolean("doenca"));

                } else {
                    System.out.println("Nenhum estudante encontrado com o ID informado.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Erro na opera��o com o banco de dados!");
            System.out.println("Detalhes: " + e.getMessage());
        }
    }
    //Trecho realizado com fim de modularizar a parte de atualização
    private void atualizarUI(String nome, String tipo, double custo, double quantiaAgua) {
        lblNome.setText("Nome: " + nome);
        lblTipo.setText("Tipo:  " + tipo);
        lblConsumo.setText("Consumo " + custo);
        double progress = quantiaAgua / 100.0;
        // Garantir que o progresso esteja entre 0 e 1 para evitar valores inválidos na ProgressBar
        pgAguaPlanta.setProgress(Math.max(0.0, Math.min(1.0, progress)));
    }

    //Metodo criado para evitar repitições no codigo
    public void novaTela(String texto) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("inserido.fxml"));
        Parent planta = loader.load();
        inseridoController controller = loader.getController();
        controller.mudarLbl(texto);
        Scene plan = new Scene(planta);
        Stage stage1= new Stage();
        stage1.setTitle("New Window");
        stage1.setScene(plan);
        stage1.show();
    }
}