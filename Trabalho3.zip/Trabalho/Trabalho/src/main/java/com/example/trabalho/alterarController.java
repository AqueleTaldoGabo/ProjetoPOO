package com.example.trabalho;


/*
Remoção de imports não utilizados
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class alterarController {
    dataSingleton data = dataSingleton.getInstance();

    @FXML
    private Button btnAlterar;

    @FXML
    private ToggleGroup grupo;

    @FXML
    private Label lblCustoNovo;

    @FXML
    private Label lblNome2;

    @FXML
    private Label lblNomeNovo;

    @FXML
    private Label lblNovoNome;

    @FXML
    private TextField nomePlanta1;

    @FXML
    private TextField nomePlanta12;

    @FXML
    private ChoiceBox<String> tipoPlanta2;

    @FXML
    private Label ttTipo;

    @FXML
    private Label tipoLbl;

    // Refatoração 1: Extraídas as opções hardcoded da ChoiceBox em uma constante para melhorar a manutenibilidade e evitar repetição.
    // Isso facilita a atualização das opções sem alterar diretamente no código.
    private static final String[] OPCOES_TIPO_PLANTA = {"Option 1", "Option 2", "Option 3"};

    @FXML
    public void initialize() {
        lblNovoNome.setText(data.getNome());
        tipoLbl.setText(data.getTipo());
        tipoPlanta2.getItems().addAll(OPCOES_TIPO_PLANTA);
    }

    // Refatoração 2: Melhorado o tratamento de erro no parsing do texto para inteiro, usando try-catch para evitar NumberFormatException.
    // Adicionado validação adicional para garantir que o valor seja positivo, melhorando a robustez do código.
    @FXML
    void btnInserir(ActionEvent event) throws IOException {
        if (tipoLbl.getText().equals("Plantas")) {
            int val = -1;
            String text = nomePlanta1.getText();
            if (!text.isBlank()) {
                try {
                    val = Integer.parseInt(text);
                    if (val < 0) {
                        val = -1; // Valor inválido, definir como -1
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Erro: Valor inválido para custo. Definindo como -1.");
                    val = -1;
                }
            }
            new Planta().mudarPlanta(lblNovoNome.getText(), nomePlanta12.getText(), val, tipoPlanta2.getValue());

        } else {
            new Inseto().mudarInseto(lblNovoNome.getText(), nomePlanta12.getText(), tipoPlanta2.getValue());
        }
        printInserido();
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.close();
    }
    void printInserido() throws IOException {
        /*
        Refatoração:
        Evitando exceções em todos fxmlloaders utilizando "Objects.requireNonNull()"
         */
        Parent planta = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("inserido.fxml")));
        Scene plan = new Scene(planta);
        Stage stage = new Stage();
        stage.setTitle("New Window");
        stage.setScene(plan);
        stage.show();
    }
}