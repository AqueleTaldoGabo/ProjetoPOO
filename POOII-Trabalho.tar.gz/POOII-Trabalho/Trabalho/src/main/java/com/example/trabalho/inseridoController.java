package com.example.trabalho;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class inseridoController {

    @FXML
    public Label inserirLbl;
    @FXML
    private Button sairBtn;

    @FXML
    void sair(ActionEvent event) {
        Stage window = (Stage)((Node) event.getSource()).getScene().getWindow();
        window.close();
    }

    void mudarLbl(String text){
        inserirLbl.setText(text);
    }
}
