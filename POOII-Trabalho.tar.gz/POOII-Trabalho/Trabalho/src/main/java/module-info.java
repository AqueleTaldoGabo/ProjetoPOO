module com.example.trabalho {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jdk.security.auth;
    requires javafx.graphics;


    opens com.example.trabalho to javafx.fxml;
    exports com.example.trabalho;
}